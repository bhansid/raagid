
# Raga Identification Program
 Designed to take in a music segment and classify it into a raga (melodic structure in Carnatic Music)
